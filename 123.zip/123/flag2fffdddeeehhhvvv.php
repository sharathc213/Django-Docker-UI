<?php session_start(); /* Starts the session */

if (isset($_SESSION['UserData']['Username'])) {


?><!DOCTYPE html>
<html lang="en">

<head>
    <div class="container">
        <div class="col-lg-4 col-md-6">
            <div class="member"  data-aos-delay="300">
                <div class="pic"><img src="marks671318123.png" class="img-fluid"></div>
            </div>
        </div>
    </div>
    
        
    
</head>
</html>
<?php
}else{
	header("Location: login.php");
			exit;
}

?>