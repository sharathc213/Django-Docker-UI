<?php session_start(); /* Starts the session */

if (isset($_SESSION['UserData']['Username'])) {


?>

Congratulation! You have logged into password protected page. <a href="logout.php">Click here</a> to Logout.
<?php

}else{
	header("Location: login.php");
			exit;
}

?>