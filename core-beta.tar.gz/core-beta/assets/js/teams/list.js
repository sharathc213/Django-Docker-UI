import Alpine from "alpinejs";
import CTFd from "../index";

window.CTFd = CTFd;
window.Alpine = Alpine;

Alpine.start();
